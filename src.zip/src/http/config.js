export const API_URL = 'https://gymvale.com/api/v1/';
