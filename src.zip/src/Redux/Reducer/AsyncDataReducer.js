// export const GET_ASYNC_DATA = 'GET_ASYNC_DATA';
import {GET_ASYNC_DATA} from '../Actions/AsyncDataAction';

const initialState = {
  data: [],
};
export default function (state = initialState, action) {
  console.log('reducer==========dd==>', action.payload);
  switch (action.type) {
    case GET_ASYNC_DATA:
      console.log('reducer============>', action.payload);
      return {
        ...state,
        data: action.payload,
      };
    default:
      return state;
  }
}
