// import { FETCH_GENRE_START, FETCH_GENRE_SUCCESS, FETCH_GENRE_ERROR } from '../action.index';


const initialState = {
  isLoading: false,
  success: false,
  error: false,
  genre: [],
};
export default function (state = initialState, action) {
 return state
}
