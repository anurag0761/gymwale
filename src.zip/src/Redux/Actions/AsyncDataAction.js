export const GET_ASYNC_DATA = 'GET_ASYNC_DATA';

export const Asyncdata = (Data) => {
    console.log('action===========>',Data)
   return {
    type: GET_ASYNC_DATA,
      payload: Data,
    };
};
